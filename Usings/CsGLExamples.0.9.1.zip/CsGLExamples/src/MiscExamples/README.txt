Miscellaneous Examples
Various Authors

Contains various examples.