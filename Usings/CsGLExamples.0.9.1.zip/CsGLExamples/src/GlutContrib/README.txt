GLUT User Contributed Examples
Various Authors
http://www.opengl.org/developers/documentation/glut/index.html

Contains ports of the examples included in GLUT, these 
were done by contributers to GLUT.