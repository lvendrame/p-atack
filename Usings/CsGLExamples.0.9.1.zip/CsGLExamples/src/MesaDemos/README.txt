Mesa Demos
The Mesa 3D Graphics Library Team
http://www.mesa3d.org

Contains ports of the demos included with Mesa3D, many by Brian Paul, 
Mark Kilgard, and others.
