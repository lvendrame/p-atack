CsGL.Basecode
The CsGL Development Team
http://csgl.sourceforge.net

Contains a simple framework for allowing you to quickly and easily 
develop OpenGL applications using CsGL.